# GC Career Studio

A conversion-focused marketing site + lead-capture backend for GC Career Studio, a career
consultancy (resumes/ATS, LinkedIn branding, job-search strategy, interview prep). Built to
evolve into a full SaaS platform (client accounts, consultant dashboards, admin CRM, payments)
without a rebuild — see `ARCHITECTURE.md` for how those pieces plug in.

## Tech stack
- **Frontend:** React 19 (CRA + craco), React Router 7, Tailwind CSS, shadcn/ui, Framer Motion, Lenis
- **Backend:** FastAPI (async), Motor (async MongoDB driver), Pydantic v2
- **Database:** MongoDB

## Project structure
```
backend/    FastAPI app, models, content data, email service, auth scaffold
frontend/   React app (pages, components, Tailwind config)
tests/      Backend test suite
memory/     Product requirements doc (PRD.md)
```

## Getting started

### Backend
```bash
cd backend
pip install -r requirements.txt
# create backend/.env with:
#   MONGO_URL=mongodb://localhost:27017
#   DB_NAME=gc_career_studio
#   CORS_ORIGINS=http://localhost:3000
#   OWNER_EMAIL=you@example.com        # optional, enables owner lead notifications
uvicorn server:app --reload
```

### Frontend
```bash
cd frontend
yarn install   # or npm install
# create frontend/.env with:
#   REACT_APP_BACKEND_URL=http://localhost:8000
yarn start
```

### Tests
```bash
cd backend
pytest
```

## Before deploying
Transactional email (`backend/email_service.py`) currently calls a Resend proxy endpoint
inherited from the original build platform (Emergent) and needs an `EMERGENT_EMAIL_KEY` that
only works inside that platform. Swap it for a direct Resend integration (or your own ESP)
before relying on it elsewhere — see the note at the top of that file.

See `ARCHITECTURE.md` for the data model, folder layout, and how auth/CRM/payments/calendar
features are meant to plug in later, and `memory/PRD.md` for the original product requirements.
