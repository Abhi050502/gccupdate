import re
import asyncio
import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter
from motor.motor_asyncio import AsyncIOMotorClient
from starlette.middleware.cors import CORSMiddleware

from content_data import METRICS, PACKAGES, SERVICES, TESTIMONIALS
from email_service import send_lead_emails
from models import Consultation, Lead, LeadCreate

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

app = FastAPI(title="GC Career Studio API")
api_router = APIRouter(prefix="/api")


@api_router.get("/")
async def health():
    return {"status": "ok", "service": "gc-career-studio"}


@api_router.post("/leads", status_code=201)
async def create_lead(payload: LeadCreate):
    lead = Lead(**payload.model_dump())
    await db.leads.insert_one(lead.model_dump())
    consultation = Consultation(
        lead_id=lead.id,
        scheduled_time=lead.preferred_time or "to be scheduled",
    )
    await db.consultations.insert_one(consultation.model_dump())
    asyncio.create_task(send_lead_emails(lead))
    return {
        "status": "received",
        "lead_id": lead.id,
        "message": "Thank you! A career consultant will reach out within 24 hours to confirm your call.",
    }


@api_router.get("/consultations/availability")
async def consultation_availability(date: str):
    cursor = db.consultations.find(
        {"scheduled_time": {"$regex": f"^{re.escape(date)}"}},
        {"_id": 0, "scheduled_time": 1},
    )
    booked = []
    async for doc in cursor:
        parts = doc.get("scheduled_time", "").split(" · ")
        if len(parts) == 2:
            booked.append(parts[1].replace(" IST", ""))
    return {"date": date, "booked": booked}


@api_router.get("/services")
async def list_services():
    return {"items": SERVICES}


@api_router.get("/packages")
async def list_packages():
    return {"items": PACKAGES, "add_ons": __import__("content_data").ADD_ONS}


@api_router.get("/testimonials")
async def list_testimonials():
    return {"items": TESTIMONIALS, "placeholder": True}


@api_router.get("/metrics")
async def list_metrics():
    return {"items": METRICS, "placeholder": True}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
