"""Transactional email via a managed Resend proxy.

NOTE: EMAIL_BASE_URL below points at the proxy provided by this project's original
build platform (Emergent) and requires an EMERGENT_EMAIL_KEY issued by that platform.
Outside that environment this will not send mail. To use Resend directly instead,
point EMAIL_BASE_URL at https://api.resend.com, send `Authorization: Bearer <RESEND_API_KEY>`
instead of the X-Email-Key header, and adjust the payload to Resend's /emails schema
(it wants `from` instead of `from_name`).
"""

import ipaddress
import logging
import os
import re
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse

import httpx
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

logger = logging.getLogger(__name__)

EMAIL_BASE_URL = "https://integrations.emergentagent.com"  # constant, not env
EMAIL_KEY = os.environ.get("EMERGENT_EMAIL_KEY", "")
EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "GC Career Studio")
EMAIL_REPLY_TO = os.environ.get("EMAIL_REPLY_TO")
OWNER_EMAIL = os.environ.get("OWNER_EMAIL", "")

_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)


def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)


def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)


class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []


def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan()
    scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r} (G2)")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links/assets must be absolute https: {url!r} (G3)")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Shortened, numeric-host or credential-bearing URL: {url!r} (G3)")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} != real link host {real!r} (G3)")


async def send_email(*, to: str, subject: str, html: str, reply_to: str | None = None) -> str | None:
    _assert_safe_email(subject, html)
    payload = {"to": [to], "subject": subject, "html": html, "from_name": EMAIL_FROM_NAME}
    if reply_to or EMAIL_REPLY_TO:
        payload["contact_email"] = reply_to or EMAIL_REPLY_TO
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{EMAIL_BASE_URL}/api/v1/email/send",
                headers={"X-Email-Key": EMAIL_KEY},
                json=payload,
            )
        resp.raise_for_status()
        return resp.json().get("id")
    except Exception as e:
        logger.error("Email send failed to %s: %s", to, e)
        return None


def _row(label: str, value: str) -> str:
    return (f'<tr><td style="padding:6px 0;color:#64748B;font-size:13px;width:140px;vertical-align:top">{escape(label)}</td>'
            f'<td style="padding:6px 0;color:#0F172A;font-size:14px">{escape(value)}</td></tr>')


async def notify_owner_of_lead(lead) -> None:
    if not OWNER_EMAIL:
        logger.info("OWNER_EMAIL not set; skipping owner notification for lead %s", lead.id)
        return
    subject = f"New consultation lead: {lead.name} ({lead.career_stage})"
    html = (
        '<table role="presentation" width="100%"><tr><td style="padding:24px;font-family:Arial,sans-serif">'
        '<p style="font-size:16px;color:#0F172A"><strong>New lead captured on GC Career Studio</strong></p>'
        '<table role="presentation">'
        + _row("Name", lead.name)
        + _row("Email", lead.email)
        + _row("Phone", lead.phone)
        + _row("Career stage", lead.career_stage)
        + _row("Primary goal", lead.goal)
        + _row("Preferred time", lead.preferred_time or "Not specified")
        + _row("Challenge", lead.challenge or "Not specified")
        + _row("Source", lead.source)
        + '</table>'
        f'<p style="font-size:12px;color:#888">Lead ID: {escape(lead.id)} &middot; Sent by {escape(EMAIL_FROM_NAME)}.</p>'
        '</td></tr></table>'
    )
    await send_email(to=OWNER_EMAIL, subject=subject, html=html)


async def send_lead_confirmation(lead) -> None:
    subject = f"We've received your consultation request, {lead.name.split()[0]}"
    html = (
        '<table role="presentation" width="100%"><tr><td style="padding:24px;font-family:Arial,sans-serif">'
        f'<p style="font-size:16px;color:#0F172A">Hi {escape(lead.name.split()[0])},</p>'
        '<p style="color:#334155;font-size:14px;line-height:1.6">Thank you for reaching out to GC Career Studio. '
        'A career consultant will contact you within 24 hours to confirm your discovery call.</p>'
        '<p style="color:#334155;font-size:14px"><strong>To make the most of your call, have these ready:</strong></p>'
        '<ul style="color:#334155;font-size:14px;line-height:1.8">'
        '<li>Your current resume (even a rough draft)</li>'
        '<li>A link to your LinkedIn profile, if you have one</li>'
        '<li>One sentence about the role you want next</li></ul>'
        f'<p style="font-size:12px;color:#888">Sent by {escape(EMAIL_FROM_NAME)}. '
        'We never ask for your password or card details by email.</p>'
        '</td></tr></table>'
    )
    await send_email(to=lead.email, subject=subject, html=html)


async def send_lead_emails(lead) -> None:
    await notify_owner_of_lead(lead)
    await send_lead_confirmation(lead)
