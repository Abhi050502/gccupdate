import uuid
from datetime import datetime, timezone
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


def new_id() -> str:
    return str(uuid.uuid4())


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class LeadCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    phone: str = Field(min_length=8, max_length=20)
    career_stage: str
    goal: str
    preferred_time: Optional[str] = None
    challenge: Optional[str] = None
    source: str = "website"


class Lead(LeadCreate):
    id: str = Field(default_factory=new_id)
    status: str = "new"  # new -> contacted -> qualified -> converted (future CRM pipeline)
    created_at: str = Field(default_factory=utcnow_iso)


class Consultation(BaseModel):
    id: str = Field(default_factory=new_id)
    lead_id: str
    scheduled_time: str = "to be scheduled"
    status: str = "requested"  # requested -> confirmed -> completed -> cancelled
    consultant_id: Optional[str] = None
    created_at: str = Field(default_factory=utcnow_iso)


class User(BaseModel):
    # Scaffold for the future client/consultant portal. Not exposed by any route yet.
    id: str = Field(default_factory=new_id)
    email: EmailStr
    hashed_password: str
    role: str = "client"  # client | consultant | admin
    created_at: str = Field(default_factory=utcnow_iso)
