import { useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { initAnalytics, pageview } from "@/lib/analytics";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Home from "@/pages/Home";
import Services from "@/pages/Services";
import About from "@/pages/About";
import Testimonials from "@/pages/Testimonials";
import Packages from "@/pages/Packages";
import Book from "@/pages/Book";
import { Toaster } from "@/components/ui/sonner";

function ScrollToTop() {
  const { pathname, search, hash } = useLocation();
  useEffect(() => {
    void initAnalytics();
  }, []);
  useEffect(() => {
    window.scrollTo(0, 0);
    pageview(`${pathname}${search}${hash}`);
  }, [pathname, search, hash]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="min-h-screen bg-[#060C16] text-slate-100 font-sans">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/about" element={<About />} />
            <Route path="/testimonials" element={<Testimonials />} />
            <Route path="/packages" element={<Packages />} />
            <Route path="/book" element={<Book />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
      </div>
      <Toaster theme="dark" position="bottom-right" />
    </BrowserRouter>
  );
}
