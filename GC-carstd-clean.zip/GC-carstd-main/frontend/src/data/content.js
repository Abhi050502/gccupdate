export const SERVICES = [
  {
    slug: "resume",
    title: "Resume & ATS Overhaul",
    tagline: "Beat the bots before you meet the humans.",
    description:
      "75% of resumes are rejected by applicant tracking systems before a recruiter ever sees them. We rebuild yours from the keyword level up.",
    outcomes: [
      "ATS-optimized resume scored against real job descriptions",
      "Achievement-driven bullet rewrites with quantified impact",
      "Role-specific versions for your top 3 target job families",
      "Recruiter-eye review by consultants who have hired at scale",
    ],
    cta: "Improve My Resume",
    testId: "service-card-resume",
  },
  {
    slug: "linkedin",
    title: "LinkedIn & Personal Branding",
    tagline: "Turn your profile into an inbound opportunity engine.",
    description:
      "Recruiters search LinkedIn before job boards. We position your headline, story, and proof so the right opportunities find you.",
    outcomes: [
      "Headline and About-section rewrite built for recruiter search",
      "Profile SEO tuned to your target role keywords",
      "Content starter kit so you post with confidence",
      "Featured-section strategy showcasing proof of work",
    ],
    cta: "Build My Brand",
    testId: "service-card-linkedin",
  },
  {
    slug: "strategy",
    title: "Job-Search Strategy",
    tagline: "Stop spraying applications. Start running a campaign.",
    description:
      "A focused search beats a frantic one. We build a targeting map, outreach scripts, and a weekly operating rhythm that compounds.",
    outcomes: [
      "Target-company map matched to your skills and goals",
      "Referral and cold-outreach scripts that get replies",
      "Weekly search cadence with application tracking",
      "Offer evaluation and salary negotiation support",
    ],
    cta: "Plan My Search",
    testId: "service-card-strategy",
  },
  {
    slug: "interview",
    title: "Interview Preparation",
    tagline: "Walk in prepared. Walk out with an offer.",
    description:
      "Structured mock interviews with consultants who have sat on the other side of the table — plus feedback you can act on immediately.",
    outcomes: [
      "2+ recorded mock interviews with scored feedback",
      "STAR answer library built from your real experience",
      "HR, technical, and case-round playbooks",
      "Salary-negotiation rehearsal for the final round",
    ],
    cta: "Ace My Interviews",
    testId: "service-card-interview",
  },
  {
    slug: "consultation",
    title: "1:1 Career Consultation",
    tagline: "Clarity on your next move, from someone unbiased.",
    description:
      "Feeling stuck, plateaued, or pulled in five directions? A structured session to map where you are, where you could go, and the fastest credible path there.",
    outcomes: [
      "Career audit: strengths, gaps, and market positioning",
      "Direction map with 2-3 viable paths, trade-offs included",
      "90-day action plan with milestones",
      "Honest assessment of transitions, incl. international moves",
    ],
    cta: "Talk to an Expert",
    testId: "service-card-consultation",
  },
];

export const PACKAGES = [
  {
    slug: "kickstart",
    name: "Career Kickstart",
    audience: "Students & freshers",
    price: "Custom quote",
    featured: false,
    features: [
      "ATS-optimized resume (1 role family)",
      "LinkedIn profile overhaul",
      "1 strategy session (60 min)",
      "Interview question bank",
      "30-day email support",
    ],
    cta: "Talk to us",
    testId: "package-card-kickstart",
    ctaTestId: "package-cta-kickstart",
  },
  {
    slug: "pro",
    name: "Professional Advancement",
    audience: "Working professionals",
    price: "Custom quote",
    featured: true,
    features: [
      "Everything in Kickstart",
      "Resume versions for 3 role families",
      "Job-search strategy & target-company map",
      "2 mock interviews with feedback",
      "Salary negotiation support",
      "60-day priority support",
    ],
    cta: "Talk to us",
    testId: "package-card-pro",
    ctaTestId: "package-cta-pro",
  },
  {
    slug: "executive",
    name: "Executive Mastery",
    audience: "Senior leaders & career transitioners",
    price: "Custom quote",
    featured: false,
    features: [
      "Everything in Professional",
      "Executive personal-branding narrative",
      "Dedicated 1:1 senior consultant",
      "Leadership & panel interview prep",
      "Transition roadmap (incl. international)",
      "90-day concierge support",
    ],
    cta: "Talk to us",
    testId: "package-card-executive",
    ctaTestId: "package-cta-executive",
  },
];

export const ADD_ONS = [
  { name: "48-hour express turnaround", note: "For urgent application deadlines" },
  { name: "Mock interview with an ex-FAANG interviewer", note: "Big-tech calibrated bar" },
  { name: "Additional resume version", note: "For a new role family or geography" },
];

export const TESTIMONIALS = [
  {
    name: "Ananya Rao",
    segment: "freshers",
    former: "Final-year B.Com student",
    current: "Analyst, Deloitte",
    hike: "First offer",
    timeline: "6 weeks",
    quote:
      "My resume was getting zero callbacks. After the rebuild I had three interviews in two weeks, and Deloitte made an offer before my final semester ended.",
  },
  {
    name: "Rohit Menon",
    segment: "tech",
    former: "Support Engineer",
    current: "Product Engineer, Razorpay",
    hike: "+52%",
    timeline: "11 weeks",
    quote:
      "The job-search strategy changed everything. I stopped mass-applying, got two referrals through the outreach scripts, and negotiated 18% above the first offer.",
  },
  {
    name: "Priya Sharma",
    segment: "transition",
    former: "School Teacher (7 yrs)",
    current: "HR Associate, Flipkart",
    hike: "+34%",
    timeline: "14 weeks",
    quote:
      "I thought switching careers at 31 meant starting from zero. They reframed my teaching experience as L&D and stakeholder management — recruiters finally got it.",
  },
  {
    name: "Vikram Iyer",
    segment: "executive",
    former: "Operations Manager",
    current: "Director of Operations, Swiggy",
    hike: "+38%",
    timeline: "9 weeks",
    quote:
      "Executive interviews are a different sport. The panel simulations and narrative coaching helped me walk into a Director-level loop and own the room.",
  },
  {
    name: "Sneha Kulkarni",
    segment: "freshers",
    former: "B.Tech graduate, tier-3 college",
    current: "SDE-1, Flipkart",
    hike: "First offer",
    timeline: "8 weeks",
    quote:
      "Coming from a tier-3 college, I assumed top product companies were closed to me. The ATS rewrite plus mock interviews proved otherwise.",
  },
  {
    name: "Arjun Nair",
    segment: "transition",
    former: "Mechanical Engineer",
    current: "Data Analyst, Amazon",
    hike: "+45%",
    timeline: "16 weeks",
    quote:
      "They mapped a 90-day pivot plan from mechanical to analytics — skills first, then positioning, then a targeted search. Every step was deliberate.",
  },
];

export const METRICS = [
  { value: "1,200+", label: "Careers transformed" },
  { value: "94%", label: "Client offer rate" },
  { value: "38%", label: "Average salary uplift" },
  { value: "6 wks", label: "Median time to offer" },
];

export const MARQUEE_ITEMS = [
  "1,200+ careers transformed",
  "Placed at Google · Amazon · Deloitte · Swiggy · Flipkart",
  "94% client offer rate",
  "38% average salary uplift",
  "Freshers to C-suite transitions",
  "Placeholder metrics — real outcomes coming soon",
];

export const IMAGES = {
  hero: "https://images.unsplash.com/photo-1551836022-b06985bceb24?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
  advisorDiscussion:
    "https://images.unsplash.com/photo-1573496267526-08a69e46a409?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
  executiveCoaching:
    "https://images.unsplash.com/photo-1551836022-4c4c79ecde51?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
  strategySession:
    "https://images.unsplash.com/photo-1714974528232-f62051870736?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
  leadAdvisorMale:
    "https://images.unsplash.com/photo-1772301685774-a4f0e81e032e?crop=entropy&cs=srgb&fm=jpg&q=85&w=800",
  leadAdvisorFemale:
    "https://images.unsplash.com/photo-1760351561005-718d0e766dac?crop=entropy&cs=srgb&fm=jpg&q=85&w=800",
  office:
    "https://images.unsplash.com/photo-1497366216548-37526070297c?crop=entropy&cs=srgb&fm=jpg&q=85&w=1200",
};

export const CONTACT = {
  email: "hello@gccareerstudio.com",
  phone: "+91 98765 43210",
  address: "WorkHub, 100 Ft Road, Indiranagar, Bengaluru 560038",
  hours: "Mon–Sat, 10:00–19:00 IST",
};
