import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import Reveal from "@/components/Reveal";
import { METRICS, IMAGES } from "@/data/content";

const PILLARS = [
  {
    title: "Evidence over adjectives",
    text: "'Hard-working team player' gets filtered. 'Cut processing time 34% across 12 branches' gets interviews. Every asset we build is proof-first.",
  },
  {
    title: "Strategy before assets",
    text: "A beautiful resume aimed at the wrong role is still a rejection. We define the target — role, level, geography — before writing a single line.",
  },
  {
    title: "Coaching, not ghostwriting",
    text: "You interview alone, so you must own your story. We build with you, explain the why, and leave you sharper — not dependent.",
  },
];

const TEAM = [
  {
    name: "Gauri C.",
    role: "Founder & Lead Career Strategist",
    tags: ["Ex-recruiter, 10+ yrs", "1,200+ placements", "Tech & product hiring"],
    image: IMAGES.leadAdvisorFemale,
  },
  {
    name: "Rahul D.",
    role: "Senior Interview Coach",
    tags: ["Ex-hiring manager", "Panel & case interviews", "Executive transitions"],
    image: IMAGES.leadAdvisorMale,
  },
];

export default function About() {
  return (
    <div data-testid="about-page" className="pt-32 lg:pt-40">
      <section className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">About GC Career Studio</p>
          <h1 className="mt-4 max-w-3xl font-serif text-4xl tracking-tight text-slate-50 sm:text-5xl lg:text-6xl">
            We sit on <span className="italic text-amber-400">your side</span> of the table.
          </h1>
        </Reveal>
      </section>

      <section className="mx-auto mt-16 grid max-w-7xl items-center gap-14 px-4 sm:px-8 lg:grid-cols-2 lg:px-16">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl">
            <img src={IMAGES.office} alt="GC Career Studio office" className="aspect-[4/3] w-full object-cover" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#060C16]/70 to-transparent" />
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">
            Why most job seekers never hear back
          </h2>
          <p className="mt-5 text-base leading-relaxed text-slate-400">
            The average corporate role attracts 250+ applications. Recruiters spend
            under 8 seconds on a first scan, and applicant tracking systems filter
            out three of four resumes before that scan even happens. Talented people
            aren't losing on ability — they're losing on presentation, positioning,
            and process.
          </p>
          <p className="mt-4 text-base leading-relaxed text-slate-400">
            GC Career Studio exists to fix exactly that. Founded by a former recruiter
            who watched great candidates get auto-rejected for formatting, we treat a
            job search like what it is: a campaign that can be engineered, measured,
            and won.
          </p>
        </Reveal>
      </section>

      <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">How we work</p>
          <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">Three pillars, no fluff.</h2>
        </Reveal>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {PILLARS.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.08}>
              <div className="h-full rounded-2xl border border-white/5 bg-[#0F1A2E] p-8">
                <span className="font-serif text-4xl text-amber-500/50">0{i + 1}</span>
                <h3 className="mt-4 font-serif text-2xl text-slate-50">{p.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-slate-400">{p.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-8 lg:px-16">
        <div className="grid gap-6 rounded-3xl border border-white/5 bg-[#0F1A2E] p-10 sm:grid-cols-4 sm:p-12">
          {METRICS.map((m, i) => (
            <Reveal key={m.label} delay={i * 0.06} className="text-center">
              <p className="font-serif text-4xl text-amber-400 sm:text-5xl">{m.value}</p>
              <p className="mt-2 text-xs uppercase tracking-wider text-slate-500">{m.label}</p>
            </Reveal>
          ))}
        </div>
        <p className="mt-3 text-center text-xs text-slate-600">Placeholder portfolio metrics — real figures published as they're audited.</p>
      </section>

      <section className="mx-auto mt-24 max-w-7xl px-4 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">The studio</p>
          <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">People who've hired, coaching people who apply.</h2>
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {TEAM.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.08}>
              <div className="group flex gap-6 rounded-2xl border border-white/5 bg-[#0F1A2E] p-6">
                <img
                  src={t.image}
                  alt={t.name}
                  loading="lazy"
                  className="h-28 w-28 shrink-0 rounded-xl object-cover grayscale transition-all duration-500 group-hover:grayscale-0"
                />
                <div>
                  <h3 className="font-serif text-2xl text-slate-50">{t.name}</h3>
                  <p className="mt-1 text-sm text-amber-400">{t.role}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {t.tags.map((tag) => (
                      <span key={tag} className="rounded-full border border-white/10 px-3 py-1 text-[11px] text-slate-400">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-8 lg:px-16">
        <Reveal>
          <div className="rounded-3xl bg-amber-500 p-10 text-center text-[#060C16] sm:p-14">
            <h2 className="font-serif text-3xl font-semibold tracking-tight sm:text-4xl">
              Ready to be read properly?
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-sm opacity-80">
              Book a free discovery call and get an honest assessment of where your search stands.
            </p>
            <Link
              to="/book"
              data-testid="about-bottom-cta"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#060C16] px-8 py-3.5 text-sm font-semibold text-amber-400 transition-transform hover:scale-[1.02]"
            >
              Book a Consultation <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
