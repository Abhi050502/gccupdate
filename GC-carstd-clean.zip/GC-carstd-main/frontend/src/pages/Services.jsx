import { Link } from "react-router-dom";
import { ArrowRight, Check, FileText, Linkedin, Compass, MessagesSquare, Users } from "lucide-react";
import Reveal from "@/components/Reveal";
import { SERVICES, IMAGES } from "@/data/content";

const ICONS = { resume: FileText, linkedin: Linkedin, strategy: Compass, interview: MessagesSquare, consultation: Users };
const SERVICE_IMAGES = [IMAGES.executiveCoaching, IMAGES.advisorDiscussion, IMAGES.strategySession];

export default function Services() {
  return (
    <div data-testid="services-page" className="pt-32 lg:pt-40">
      <section className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">Services</p>
          <h1 className="mt-4 max-w-3xl font-serif text-4xl tracking-tight text-slate-50 sm:text-5xl lg:text-6xl">
            Everything between <span className="italic text-amber-400">"I need a job"</span> and "I accept."
          </h1>
          <p className="mt-6 max-w-2xl text-lg font-light leading-relaxed text-slate-300">
            Each service stands alone — but they compound. Start where it hurts most,
            or let a free consultation tell you where that is.
          </p>
        </Reveal>
      </section>

      <section className="mx-auto mt-20 max-w-7xl space-y-8 px-4 pb-10 sm:px-8 lg:px-16">
        {SERVICES.map((s, i) => {
          const Icon = ICONS[s.slug];
          const flipped = i % 2 === 1;
          return (
            <Reveal key={s.slug}>
              <article
                data-testid={s.testId}
                className="grid overflow-hidden rounded-3xl border border-white/5 bg-[#0F1A2E] lg:grid-cols-[1.2fr_0.8fr]"
              >
                <div className={`p-8 sm:p-12 ${flipped ? "lg:order-2" : ""}`}>
                  <div className="flex items-center gap-4">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/10">
                      <Icon className="h-6 w-6 text-amber-500" />
                    </span>
                    <span className="font-mono text-xs text-slate-500">0{i + 1}</span>
                  </div>
                  <h2 className="mt-6 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">{s.title}</h2>
                  <p className="mt-2 font-serif text-lg italic text-amber-400/90">{s.tagline}</p>
                  <p className="mt-4 max-w-xl text-sm leading-relaxed text-slate-400">{s.description}</p>
                  <div className="mt-8">
                    <p className="font-mono text-xs uppercase tracking-[0.25em] text-slate-500">What you walk away with</p>
                    <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                      {s.outcomes.map((o) => (
                        <li key={o} className="flex items-start gap-2 text-sm text-slate-300">
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" /> {o}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Link
                    to="/book"
                    data-testid={`service-cta-${s.slug}`}
                    className="group mt-9 inline-flex items-center gap-2 rounded-full bg-amber-500 px-6 py-3 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400"
                  >
                    {s.cta}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
                <div className={`relative min-h-[240px] ${flipped ? "lg:order-1" : ""}`}>
                  <img
                    src={SERVICE_IMAGES[i % SERVICE_IMAGES.length]}
                    alt=""
                    className="absolute inset-0 h-full w-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-[#0F1A2E] via-[#0F1A2E]/30 to-transparent" />
                </div>
              </article>
            </Reveal>
          );
        })}
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-24 pt-10 sm:px-8 lg:px-16">
        <Reveal>
          <div className="rounded-3xl border border-amber-500/25 bg-[#0F1A2E]/60 p-10 text-center sm:p-14">
            <h2 className="font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">
              Can't decide? <span className="italic text-amber-400">That's what the free call is for.</span>
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm text-slate-400">
              Twenty minutes, zero obligation. We'll tell you exactly which lever moves your search fastest.
            </p>
            <Link
              to="/book"
              data-testid="services-bottom-cta"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-amber-500 px-8 py-3.5 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400"
            >
              Book a Consultation <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
