import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  ArrowRight, FileText, Linkedin, Compass, MessagesSquare, Users,
  TrendingUp, Quote, Check,
} from "lucide-react";
import Reveal from "@/components/Reveal";
import Marquee from "@/components/Marquee";
import LeadForm from "@/components/LeadForm";
import { trackEvent } from "@/lib/analytics";
import { SERVICES, PACKAGES, TESTIMONIALS, METRICS, MARQUEE_ITEMS, IMAGES } from "@/data/content";

const HERO_LINES = ["Your next role", "isn't found.", "It's engineered."];

const SERVICE_ICONS = { resume: FileText, linkedin: Linkedin, strategy: Compass, interview: MessagesSquare, consultation: Users };

const CHAPTERS = [
  {
    num: "01",
    problem: "The ATS black hole",
    detail: "You apply to 50 jobs. Silence. Applicant tracking systems reject 75% of resumes before a human ever reads one — usually for formatting and keywords, not competence.",
    solution: "Resume & ATS Overhaul",
    slug: "resume",
  },
  {
    num: "02",
    problem: "The invisible profile",
    detail: "Recruiters search LinkedIn before job boards. If your headline reads like a job title and your About section is empty, you simply don't exist in their results.",
    solution: "LinkedIn & Personal Branding",
    slug: "linkedin",
  },
  {
    num: "03",
    problem: "The spray-and-pray search",
    detail: "Mass-applying feels productive but converts at under 2%. Without a target map, outreach scripts, and a weekly rhythm, effort scatters instead of compounding.",
    solution: "Job-Search Strategy",
    slug: "strategy",
  },
  {
    num: "04",
    problem: "The interview freeze",
    detail: "You know your work — until someone asks you to walk them through it. Unprepared answers cost offers even when the resume did its job perfectly.",
    solution: "Interview Preparation",
    slug: "interview",
  },
];

const JOURNEY = [
  { step: "01", title: "Discover", text: "Book a free consultation. We listen — goals, blockers, timeline — before we prescribe anything." },
  { step: "02", title: "Diagnose", text: "A full career audit: resume, LinkedIn, positioning, and the gap between you and your target role." },
  { step: "03", title: "Build", text: "We rebuild your assets — resume, brand, strategy — and rehearse the interviews that matter." },
  { step: "04", title: "Convert", text: "You run a focused search with our support until the offer lands. Then we help you negotiate it." },
];

function Estimator() {
  const [stage, setStage] = useState("fresher");
  const [effort, setEffort] = useState("guided");
  const base = { student: 18, fresher: 32, professional: 38, transition: 41 }[stage];
  const mult = { solo: 0.4, guided: 1, intensive: 1.35 }[effort];
  const uplift = Math.round(base * mult);
  return (
    <div className="grid gap-6 md:grid-cols-[1fr_auto] md:items-end">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="field-label" htmlFor="est-stage">Where are you today?</label>
          <select id="est-stage" data-testid="estimator-stage" className="field-input" value={stage} onChange={(e) => setStage(e.target.value)}>
            <option value="student">College student</option>
            <option value="fresher">Fresher / recent graduate</option>
            <option value="professional">Working professional</option>
            <option value="transition">Career transitioner</option>
          </select>
        </div>
        <div>
          <label className="field-label" htmlFor="est-effort">How do you search?</label>
          <select id="est-effort" data-testid="estimator-effort" className="field-input" value={effort} onChange={(e) => setEffort(e.target.value)}>
            <option value="solo">On my own, ad hoc</option>
            <option value="guided">With a structured plan</option>
            <option value="intensive">Fully coached, end to end</option>
          </select>
        </div>
      </div>
      <div className="rounded-2xl border border-amber-500/30 bg-[#060C16] px-8 py-6 text-center">
        <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-slate-500">Typical client uplift</p>
        <p data-testid="estimator-result" className="font-serif text-5xl font-semibold text-amber-400">
          ~{uplift}%
        </p>
        <p className="mt-1 text-xs text-slate-500">salary improvement vs. going it alone*</p>
      </div>
    </div>
  );
}

export default function Home() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const [activeChapter, setActiveChapter] = useState(0);

  return (
    <div data-testid="home-page">
      {/* HERO */}
      <section ref={heroRef} className="relative overflow-hidden pt-36 pb-20 lg:pt-44 lg:pb-28">
        <div
          className="pointer-events-none absolute -top-40 right-0 h-[600px] w-[600px] rounded-full opacity-20"
          style={{ background: "radial-gradient(circle, #F59E0B 0%, transparent 60%)" }}
          aria-hidden="true"
        />
        <div className="mx-auto grid max-w-7xl items-center gap-16 px-4 sm:px-8 lg:grid-cols-[1.15fr_0.85fr] lg:px-16">
          <div>
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="eyebrow"
            >
              Career Consultancy — for the ambitious
            </motion.p>
            <h1
              data-testid="hero-title"
              className="mt-6 font-serif text-5xl font-medium leading-[1.05] tracking-tight text-slate-50 sm:text-6xl lg:text-7xl"
            >
              {HERO_LINES.map((line, i) => (
                <span key={line} className="block overflow-hidden pb-1">
                  <motion.span
                    className={`block ${i === 2 ? "text-amber-400 italic" : ""}`}
                    initial={{ y: "110%" }}
                    animate={{ y: 0 }}
                    transition={{ duration: 0.9, delay: 0.15 + i * 0.14, ease: [0.16, 1, 0.3, 1] }}
                  >
                    {line}
                  </motion.span>
                </span>
              ))}
            </h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.7 }}
              className="mt-6 max-w-xl text-lg font-light leading-relaxed text-slate-300"
            >
              GC Career Studio turns overlooked profiles into interview magnets —
              ATS-proof resumes, magnetic LinkedIn brands, and interview coaching
              that converts. For students, freshers, professionals, and career changers.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.9 }}
              className="mt-10 flex flex-wrap items-center gap-4"
            >
              <Link
                to="/book"
                data-testid="hero-primary-cta"
                onClick={() => trackEvent("cta_click", { cta: "book_consultation", location: "hero" })}
                className="group flex items-center gap-2 rounded-full bg-amber-500 px-7 py-3.5 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400"
              >
                Book a Consultation
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/services"
                data-testid="hero-secondary-cta"
                className="rounded-full border border-white/15 px-7 py-3.5 text-sm font-medium text-slate-200 transition-colors hover:border-amber-500/50 hover:text-amber-400"
              >
                Explore Services
              </Link>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1.15 }}
              className="mt-12 flex flex-wrap gap-3"
            >
              {METRICS.slice(0, 3).map((m) => (
                <div key={m.label} className="rounded-full border border-white/10 bg-[#0F1A2E]/60 px-4 py-2">
                  <span className="font-serif text-lg text-amber-400">{m.value}</span>{" "}
                  <span className="text-xs text-slate-400">{m.label}</span>
                </div>
              ))}
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="relative hidden lg:block"
          >
            <div className="absolute -left-4 -top-4 h-full w-full rounded-2xl border border-amber-500/30" aria-hidden="true" />
            <motion.div style={{ y: imgY }} className="relative overflow-hidden rounded-2xl">
              <img
                src={IMAGES.hero}
                alt="Career consultation session"
                className="aspect-[4/5] w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060C16]/80 via-transparent to-transparent" />
            </motion.div>
            <div className="absolute -bottom-6 -left-10 rounded-xl border border-amber-500/20 bg-[#0F1A2E] p-5 shadow-2xl">
              <div className="flex items-center gap-3">
                <TrendingUp className="h-8 w-8 text-amber-500" />
                <div>
                  <p className="font-serif text-2xl text-slate-50">+38%</p>
                  <p className="text-xs text-slate-400">avg. salary uplift*</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Marquee items={MARQUEE_ITEMS} />

      {/* PROBLEM → SOLUTION MANIFESTO */}
      <section className="py-20 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
          <Reveal>
            <p className="eyebrow">The manifesto</p>
            <h2 className="mt-4 max-w-2xl font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
              The job market isn't unfair. It's <span className="italic text-amber-400">unread.</span>
            </h2>
            <p className="mt-4 max-w-xl text-base text-slate-400">
              Four problems quietly kill most careers searches. Here's each one — and exactly how we fix it.
            </p>
          </Reveal>
          <div className="mt-14 space-y-4">
            {CHAPTERS.map((c, i) => (
              <Reveal key={c.num} delay={i * 0.05}>
                <button
                  data-testid={`problem-chapter-${i + 1}`}
                  onClick={() => setActiveChapter(i)}
                  className={`group grid w-full gap-4 rounded-2xl border p-6 text-left transition-colors sm:grid-cols-[80px_1fr_auto] sm:items-center sm:p-8 ${
                    activeChapter === i
                      ? "border-amber-500/50 bg-[#0F1A2E]"
                      : "border-white/5 bg-transparent hover:border-amber-500/25"
                  }`}
                >
                  <span className="font-serif text-4xl text-amber-500/70">{c.num}</span>
                  <span>
                    <span className="block font-serif text-2xl text-slate-50">{c.problem}</span>
                    {activeChapter === i && (
                      <motion.span
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        className="mt-3 block max-w-2xl text-sm leading-relaxed text-slate-400"
                      >
                        {c.detail}
                        <Link
                          to="/services"
                          className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-amber-400 hover:text-amber-300"
                        >
                          Our fix: {c.solution} <ArrowRight className="h-3.5 w-3.5" />
                        </Link>
                      </motion.span>
                    )}
                  </span>
                  <ArrowRight
                    className={`hidden h-5 w-5 transition-transform sm:block ${
                      activeChapter === i ? "rotate-90 text-amber-400" : "text-slate-600 group-hover:text-amber-400"
                    }`}
                  />
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES OVERVIEW */}
      <section className="border-t border-white/5 py-20 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="eyebrow">What we do</p>
              <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
                Five levers. One outcome: <span className="italic text-amber-400">offers.</span>
              </h2>
            </div>
            <Link to="/services" className="group flex items-center gap-2 text-sm font-medium text-amber-400 hover:text-amber-300">
              All services in detail <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Reveal>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((s, i) => {
              const Icon = SERVICE_ICONS[s.slug];
              return (
                <Reveal key={s.slug} delay={i * 0.06}>
                  <Link
                    to="/services"
                    data-testid={s.testId}
                    className="group block h-full rounded-2xl border border-white/5 bg-[#0F1A2E] p-7 transition-colors hover:border-amber-500/40 hover:bg-[#162542]"
                  >
                    <Icon className="h-7 w-7 text-amber-500" />
                    <h3 className="mt-5 font-serif text-2xl text-slate-50">{s.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-400">{s.tagline}</p>
                    <span className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-amber-400">
                      {s.cta} <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                    </span>
                  </Link>
                </Reveal>
              );
            })}
            <Reveal delay={0.3}>
              <Link
                to="/book"
                className="flex h-full flex-col justify-center rounded-2xl bg-amber-500 p-7 text-[#060C16] transition-colors hover:bg-amber-400"
              >
                <h3 className="font-serif text-2xl font-semibold">Not sure where to start?</h3>
                <p className="mt-2 text-sm opacity-80">A free 20-minute discovery call will tell you.</p>
                <span className="mt-5 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider">
                  Talk to an Expert <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ESTIMATOR */}
      <section className="border-t border-white/5 py-20 lg:py-28">
        <div className="mx-auto max-w-5xl px-4 sm:px-8 lg:px-16">
          <Reveal>
            <div className="rounded-3xl border border-white/5 bg-[#0F1A2E] p-8 sm:p-12">
              <p className="eyebrow">Interactive</p>
              <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">
                What's a guided search worth?
              </h2>
              <p className="mt-3 max-w-xl text-sm text-slate-400">
                Based on outcomes across 1,200+ client engagements.*
              </p>
              <div className="mt-10">
                <Estimator />
              </div>
              <p className="mt-6 text-xs text-slate-600">*Illustrative estimate from placeholder portfolio metrics.</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="border-t border-white/5 py-20 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
          <Reveal>
            <p className="eyebrow">The journey</p>
            <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
              From stuck to signed, in <span className="italic text-amber-400">four moves.</span>
            </h2>
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {JOURNEY.map((j, i) => (
              <Reveal key={j.step} delay={i * 0.08}>
                <div className="relative h-full rounded-2xl border border-white/5 p-7">
                  <span className="font-serif text-5xl text-amber-500/25">{j.step}</span>
                  <h3 className="mt-4 font-serif text-2xl text-slate-50">{j.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-400">{j.text}</p>
                  {i === 0 && (
                    <Link
                      to="/book"
                      data-testid="journey-step-cta"
                      className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-amber-400 hover:text-amber-300"
                    >
                      Start here <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  )}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS PREVIEW */}
      <section className="border-t border-white/5 py-20 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="eyebrow">Success stories</p>
              <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
                They were stuck too.
              </h2>
              <p className="mt-3 text-xs text-slate-500">Representative placeholder stories — real client outcomes being collected.</p>
            </div>
            <Link to="/testimonials" className="group flex items-center gap-2 text-sm font-medium text-amber-400 hover:text-amber-300">
              All success stories <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {TESTIMONIALS.slice(0, 3).map((t, i) => (
              <Reveal key={t.name} delay={i * 0.08}>
                <figure className="flex h-full flex-col rounded-2xl border border-white/5 bg-[#0F1A2E] p-7">
                  <Quote className="h-6 w-6 text-amber-500/60" />
                  <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-slate-300">"{t.quote}"</blockquote>
                  <figcaption className="mt-6 border-t border-white/5 pt-4">
                    <p className="font-medium text-slate-100">{t.name}</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {t.former} → <span className="text-amber-400">{t.current}</span>
                    </p>
                    <p className="mt-1 font-mono text-xs text-slate-500">{t.hike} · {t.timeline}</p>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PACKAGES TEASER */}
      <section className="border-t border-white/5 py-20 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="eyebrow">Engagement packages</p>
              <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
                Pick your altitude.
              </h2>
            </div>
            <Link to="/packages" className="group flex items-center gap-2 text-sm font-medium text-amber-400 hover:text-amber-300">
              Compare packages <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {PACKAGES.map((p, i) => (
              <Reveal key={p.slug} delay={i * 0.08}>
                <div
                  data-testid={p.testId}
                  className={`flex h-full flex-col rounded-2xl border p-7 ${
                    p.featured ? "border-amber-500/50 bg-[#0F1A2E]" : "border-white/5 bg-transparent"
                  }`}
                >
                  {p.featured && (
                    <span className="mb-4 w-max rounded-full bg-amber-500/10 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-amber-400">
                      Most chosen
                    </span>
                  )}
                  <h3 className="font-serif text-2xl text-slate-50">{p.name}</h3>
                  <p className="mt-1 text-xs text-slate-500">{p.audience}</p>
                  <p className="mt-4 font-serif text-xl text-amber-400">{p.price}</p>
                  <ul className="mt-5 flex-1 space-y-2.5">
                    {p.features.slice(0, 4).map((f) => (
                      <li key={f} className="flex items-start gap-2 text-sm text-slate-300">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/book"
                    data-testid={p.ctaTestId}
                    className={`mt-7 rounded-full py-3 text-center text-sm font-semibold transition-colors ${
                      p.featured
                        ? "bg-amber-500 text-[#060C16] hover:bg-amber-400"
                        : "border border-white/15 text-slate-200 hover:border-amber-500/50 hover:text-amber-400"
                    }`}
                  >
                    {p.cta}
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* LEAD CAPTURE */}
      <section className="border-t border-amber-500/15 bg-[#0F1A2E]/40 py-20 lg:py-32">
        <div className="mx-auto grid max-w-7xl items-start gap-14 px-4 sm:px-8 lg:grid-cols-2 lg:px-16">
          <Reveal>
            <p className="eyebrow">Free 20-minute discovery call</p>
            <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
              Tell us where you're stuck. <span className="italic text-amber-400">We'll map the way out.</span>
            </h2>
            <p className="mt-5 max-w-md text-base leading-relaxed text-slate-400">
              No pitch decks, no pressure. A real conversation about your situation,
              an honest read on your positioning, and a clear recommendation — whether
              or not you ever become a client.
            </p>
            <ul className="mt-8 space-y-3">
              {["Response within 24 hours", "Zero obligation, zero spam", "Tailored to students, freshers, professionals & transitioners"].map((x) => (
                <li key={x} className="flex items-center gap-3 text-sm text-slate-300">
                  <Check className="h-4 w-4 text-amber-500" /> {x}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="rounded-3xl border border-white/10 bg-[#060C16] p-8 sm:p-10">
              <LeadForm source="home-banner" />
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
