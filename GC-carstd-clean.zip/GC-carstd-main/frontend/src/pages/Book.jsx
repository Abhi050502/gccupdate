import { useState } from "react";
import { ArrowRight, Mail, Phone, MapPin, Clock } from "lucide-react";
import Reveal from "@/components/Reveal";
import LeadForm from "@/components/LeadForm";
import SlotPicker from "@/components/SlotPicker";
import { CONTACT } from "@/data/content";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = [
  {
    q: "Is the discovery call really free?",
    a: "Yes — 20 minutes, no charge, no obligation. We assess your situation and tell you honestly whether (and how) we can help.",
  },
  {
    q: "How fast will I hear back?",
    a: "Within 24 hours on business days. You'll get a confirmation email immediately after submitting this form.",
  },
  {
    q: "Do you work with people outside India?",
    a: "Yes. Consultations run over video call, and we regularly support clients targeting international roles and relocations.",
  },
  {
    q: "What should I prepare before the call?",
    a: "Your current resume (a rough draft is fine), your LinkedIn URL if you have one, and one sentence about the role you want next.",
  },
];

export default function Book() {
  const [step, setStep] = useState(1);
  const [slot, setSlot] = useState("");

  return (
    <div data-testid="book-page" className="pt-32 lg:pt-40">
      <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">Book a consultation</p>
          <h1 className="mt-4 max-w-3xl font-serif text-4xl tracking-tight text-slate-50 sm:text-5xl lg:text-6xl">
            Twenty minutes that can <span className="italic text-amber-400">redirect a career.</span>
          </h1>
        </Reveal>

        <div className="mt-14 grid items-start gap-12 lg:grid-cols-[1.15fr_0.85fr]">
          <Reveal delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-[#0F1A2E] p-8 sm:p-10">
              <div className="mb-8 flex items-center gap-3" data-testid="booking-steps">
                {["Pick a slot", "Your details"].map((label, i) => (
                  <div key={label} className="flex items-center gap-3">
                    <span
                      className={`flex h-7 w-7 items-center justify-center rounded-full font-mono text-xs ${
                        step > i ? "bg-amber-500 text-[#060C16] font-semibold" : "border border-white/15 text-slate-500"
                      }`}
                    >
                      {i + 1}
                    </span>
                    <span className={`text-xs uppercase tracking-wider ${step > i ? "text-amber-400" : "text-slate-500"}`}>
                      {label}
                    </span>
                    {i === 0 && <span className="mx-1 h-px w-8 bg-white/10" />}
                  </div>
                ))}
              </div>

              {step === 1 ? (
                <div>
                  <SlotPicker value={slot} onChange={setSlot} />
                  <div className="mt-8 flex flex-wrap items-center gap-4">
                    <button
                      data-testid="booking-continue-btn"
                      disabled={!slot}
                      onClick={() => setStep(2)}
                      className="flex items-center gap-2 rounded-full bg-amber-500 px-7 py-3 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Continue <ArrowRight className="h-4 w-4" />
                    </button>
                    <button
                      data-testid="booking-flexible-btn"
                      onClick={() => {
                        setSlot("Flexible — please suggest a time");
                        setStep(2);
                      }}
                      className="text-sm text-slate-400 underline-offset-4 transition-colors hover:text-amber-400 hover:underline"
                    >
                      I'm flexible — suggest a time for me
                    </button>
                  </div>
                </div>
              ) : (
                <LeadForm source="book-page" preferredTime={slot} onEditSlot={() => setStep(1)} />
              )}
            </div>
          </Reveal>

          <Reveal delay={0.2} className="space-y-6">
            <div className="rounded-2xl border border-amber-500/25 bg-amber-500/5 p-7">
              <h3 className="font-serif text-xl text-slate-50">How scheduling works</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">
                Pick any open slot on the left. Booked slots lock automatically, and you'll get an
                email confirmation with the video-call link once we accept the request.
              </p>
            </div>

            <div className="rounded-2xl border border-white/5 bg-[#0F1A2E] p-7">
              <h3 className="font-serif text-xl text-slate-50">Prefer to reach out directly?</h3>
              <ul className="mt-5 space-y-4 text-sm text-slate-300">
                <li>
                  <a href={`mailto:${CONTACT.email}`} data-testid="book-email-link" className="flex items-center gap-3 transition-colors hover:text-amber-400">
                    <Mail className="h-4 w-4 text-amber-500" /> {CONTACT.email}
                  </a>
                </li>
                <li>
                  <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} data-testid="book-phone-link" className="flex items-center gap-3 transition-colors hover:text-amber-400">
                    <Phone className="h-4 w-4 text-amber-500" /> {CONTACT.phone}
                  </a>
                </li>
                <li className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" /> {CONTACT.address}
                </li>
                <li className="flex items-center gap-3 text-slate-400">
                  <Clock className="h-4 w-4 text-amber-500" /> {CONTACT.hours}
                </li>
              </ul>
            </div>

            <div className="rounded-2xl border border-white/5 bg-[#0F1A2E] p-7">
              <h3 className="font-serif text-xl text-slate-50">Common questions</h3>
              <Accordion type="single" collapsible className="mt-4" data-testid="book-faq">
                {FAQ.map((f, i) => (
                  <AccordionItem key={f.q} value={`faq-${i}`} className="border-white/5">
                    <AccordionTrigger className="text-left text-sm text-slate-200 hover:text-amber-400">
                      {f.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-sm leading-relaxed text-slate-400">
                      {f.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
