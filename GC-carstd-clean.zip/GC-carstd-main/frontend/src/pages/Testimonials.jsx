import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Quote, ArrowRightLeft } from "lucide-react";
import Reveal from "@/components/Reveal";
import { TESTIMONIALS, METRICS } from "@/data/content";

const FILTERS = [
  { key: "all", label: "All", testId: "testimonial-filter-all" },
  { key: "freshers", label: "Freshers & Graduates", testId: "testimonial-filter-freshers" },
  { key: "tech", label: "Tech & Product", testId: "testimonial-filter-tech" },
  { key: "transition", label: "Career Transitioners", testId: "testimonial-filter-transition" },
  { key: "executive", label: "Executive Leadership", testId: "testimonial-filter-executives" },
];

export default function Testimonials() {
  const [filter, setFilter] = useState("all");
  const visible = filter === "all" ? TESTIMONIALS : TESTIMONIALS.filter((t) => t.segment === filter);

  return (
    <div data-testid="testimonials-page" className="pt-32 lg:pt-40">
      <section className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">Success stories</p>
          <h1 className="mt-4 max-w-3xl font-serif text-4xl tracking-tight text-slate-50 sm:text-5xl lg:text-6xl">
            From overlooked to <span className="italic text-amber-400">offer letter.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg font-light leading-relaxed text-slate-300">
            Every story below is a placeholder composite of real engagement patterns,
            structured so genuine client outcomes drop straight in.
          </p>
        </Reveal>

        <div className="mt-10 grid gap-4 sm:grid-cols-4">
          {METRICS.map((m, i) => (
            <Reveal key={m.label} delay={i * 0.05}>
              <div className="rounded-2xl border border-white/5 bg-[#0F1A2E] p-6 text-center">
                <p className="font-serif text-3xl text-amber-400">{m.value}</p>
                <p className="mt-1 text-xs uppercase tracking-wider text-slate-500">{m.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto mt-16 max-w-7xl px-4 pb-24 sm:px-8 lg:px-16">
        <div className="flex flex-wrap gap-3" role="tablist" aria-label="Filter stories">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              role="tab"
              aria-selected={filter === f.key}
              data-testid={f.testId}
              onClick={() => setFilter(f.key)}
              className={`rounded-full px-5 py-2.5 text-sm transition-colors ${
                filter === f.key
                  ? "bg-amber-500 font-semibold text-[#060C16]"
                  : "border border-white/10 text-slate-300 hover:border-amber-500/40 hover:text-amber-400"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <AnimatePresence mode="popLayout">
            {visible.map((t) => (
              <motion.figure
                key={t.name}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="flex flex-col rounded-2xl border border-white/5 bg-[#0F1A2E] p-8"
              >
                <Quote className="h-6 w-6 text-amber-500/60" />
                <blockquote className="mt-4 flex-1 text-base leading-relaxed text-slate-200">
                  "{t.quote}"
                </blockquote>
                <div className="mt-6 flex items-center gap-3 rounded-xl bg-[#060C16] p-4">
                  <ArrowRightLeft className="h-4 w-4 shrink-0 text-amber-500" />
                  <div className="text-sm">
                    <span className="text-slate-400">{t.former}</span>
                    <span className="mx-2 text-slate-600">→</span>
                    <span className="font-medium text-amber-400">{t.current}</span>
                  </div>
                </div>
                <figcaption className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-white/5 pt-4">
                  <div>
                    <p className="font-medium text-slate-100">{t.name}</p>
                    <p className="font-mono text-xs text-slate-500">{t.hike} · {t.timeline} to offer</p>
                  </div>
                  <span className="rounded-full bg-amber-500/10 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.15em] text-amber-400">
                    Placeholder story
                  </span>
                </figcaption>
              </motion.figure>
            ))}
          </AnimatePresence>
        </div>

        <Reveal className="mt-16">
          <div className="rounded-3xl border border-amber-500/25 bg-[#0F1A2E]/60 p-10 text-center sm:p-14">
            <h2 className="font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">
              Your story could be next.
            </h2>
            <Link
              to="/book"
              data-testid="testimonials-bottom-cta"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-amber-500 px-8 py-3.5 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400"
            >
              Start With a Free Consultation <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
