import { Link } from "react-router-dom";
import { ArrowRight, Check, Plus } from "lucide-react";
import Reveal from "@/components/Reveal";
import { PACKAGES, ADD_ONS } from "@/data/content";
import { trackEvent } from "@/lib/analytics";

export default function Packages() {
  return (
    <div data-testid="packages-page" className="pt-32 lg:pt-40">
      <section className="mx-auto max-w-7xl px-4 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">Packages</p>
          <h1 className="mt-4 max-w-3xl font-serif text-4xl tracking-tight text-slate-50 sm:text-5xl lg:text-6xl">
            Transparent scope. <span className="italic text-amber-400">Honest advice.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg font-light leading-relaxed text-slate-300">
            Pricing is tailored to your situation and confirmed on a free discovery call —
            no surprise invoices, no upsell pressure. Pick the tier that fits, then talk to us.
          </p>
        </Reveal>
      </section>

      <section className="mx-auto mt-16 max-w-7xl px-4 sm:px-8 lg:px-16">
        <div className="grid gap-6 lg:grid-cols-3">
          {PACKAGES.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.08} className="h-full">
              <div
                data-testid={p.testId}
                className={`relative flex h-full flex-col rounded-3xl border p-8 sm:p-10 ${
                  p.featured
                    ? "border-amber-500/60 bg-[#0F1A2E] shadow-[0_0_60px_rgba(245,158,11,0.08)]"
                    : "border-white/5 bg-[#0F1A2E]/40"
                }`}
              >
                {p.featured && (
                  <span className="absolute -top-3 left-8 rounded-full bg-amber-500 px-4 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-[#060C16]">
                    Most chosen
                  </span>
                )}
                <h2 className="font-serif text-3xl text-slate-50">{p.name}</h2>
                <p className="mt-1 text-sm text-slate-500">{p.audience}</p>
                <p className="mt-6 font-serif text-2xl text-amber-400">{p.price}</p>
                <p className="mt-1 text-xs text-slate-500">Confirmed on your discovery call</p>
                <ul className="mt-8 flex-1 space-y-3.5">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm text-slate-300">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" /> {f}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/book"
                  data-testid={p.ctaTestId}
                  className={`mt-10 rounded-full py-3.5 text-center text-sm font-semibold transition-colors ${
                    p.featured
                      ? "bg-amber-500 text-[#060C16] hover:bg-amber-400"
                      : "border border-white/15 text-slate-200 hover:border-amber-500/50 hover:text-amber-400"
                  }`}
                >
                  {p.cta}
                </Link>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto mt-20 max-w-7xl px-4 pb-24 sm:px-8 lg:px-16">
        <Reveal>
          <p className="eyebrow">Add-ons</p>
          <h2 className="mt-4 font-serif text-3xl tracking-tight text-slate-50 sm:text-4xl">Bolt on extra firepower.</h2>
        </Reveal>
        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {ADD_ONS.map((a, i) => (
            <Reveal key={a.name} delay={i * 0.06}>
              <div className="flex h-full items-start gap-4 rounded-2xl border border-white/5 bg-[#0F1A2E] p-6">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-500/10">
                  <Plus className="h-4 w-4 text-amber-500" />
                </span>
                <div>
                  <p className="text-sm font-medium text-slate-100">{a.name}</p>
                  <p className="mt-1 text-xs text-slate-500">{a.note}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-14">
          <div className="flex flex-col items-center gap-5 rounded-3xl border border-white/5 bg-[#060C16] p-10 text-center">
            <p className="max-w-lg text-sm leading-relaxed text-slate-400">
              Online checkout is coming soon. For now, every engagement starts with a
              conversation — so you only ever pay for what you actually need.
            </p>
            <Link
              to="/book"
              data-testid="packages-bottom-cta"
              className="inline-flex items-center gap-2 rounded-full bg-amber-500 px-8 py-3.5 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400"
            >
              Talk to Us <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
