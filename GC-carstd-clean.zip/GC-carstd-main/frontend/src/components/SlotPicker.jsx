import { useEffect, useMemo, useState } from "react";
import { Check } from "lucide-react";
import { api } from "@/lib/api";

const TIMES = ["10:00 AM", "11:00 AM", "12:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM", "06:00 PM"];
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function buildDays(count = 14) {
  const days = [];
  const d = new Date();
  d.setDate(d.getDate() + 1); // earliest booking: tomorrow
  while (days.length < count) {
    if (d.getDay() !== 0) {
      // Sundays closed
      const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      days.push({ iso, weekday: WEEKDAYS[d.getDay()], day: d.getDate(), month: MONTHS[d.getMonth()] });
    }
    d.setDate(d.getDate() + 1);
  }
  return days;
}

export const slotLabel = (iso, time) => `${iso} · ${time} IST`;

export const SlotPicker = ({ value, onChange }) => {
  const days = useMemo(() => buildDays(14), []);
  const selectedIso = value ? value.split(" · ")[0] : "";
  const selectedTime = value ? value.split(" · ")[1]?.replace(" IST", "") : "";
  const [date, setDate] = useState(selectedIso || days[0].iso);
  const [booked, setBooked] = useState([]);

  useEffect(() => {
    let cancelled = false;
    api
      .get("/consultations/availability", { params: { date } })
      .then((r) => !cancelled && setBooked(r.data.booked || []))
      .catch(() => !cancelled && setBooked([]));
    return () => {
      cancelled = true;
    };
  }, [date]);

  return (
    <div data-testid="slot-picker">
      <p className="field-label">Pick a date (IST)</p>
      <div className="flex gap-2 overflow-x-auto pb-2">
        {days.map((d) => (
          <button
            key={d.iso}
            type="button"
            data-testid={`slot-date-${d.iso}`}
            onClick={() => setDate(d.iso)}
            className={`flex w-16 shrink-0 flex-col items-center rounded-xl border py-3 transition-colors ${
              date === d.iso
                ? "border-amber-500 bg-amber-500/10 text-amber-400"
                : "border-white/10 text-slate-400 hover:border-amber-500/40 hover:text-slate-200"
            }`}
          >
            <span className="font-mono text-[10px] uppercase tracking-wider">{d.weekday}</span>
            <span className="mt-1 font-serif text-xl">{d.day}</span>
            <span className="font-mono text-[10px] uppercase">{d.month}</span>
          </button>
        ))}
      </div>

      <p className="field-label mt-6">Pick a time</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {TIMES.map((t) => {
          const taken = booked.includes(t);
          const active = date === selectedIso && selectedTime === t;
          return (
            <button
              key={t}
              type="button"
              data-testid={`slot-time-${t.replace(/[: ]/g, "-")}`}
              disabled={taken}
              onClick={() => onChange(slotLabel(date, t))}
              className={`flex items-center justify-center gap-1.5 rounded-lg border py-2.5 text-sm transition-colors ${
                taken
                  ? "cursor-not-allowed border-white/5 text-slate-600 line-through"
                  : active
                    ? "border-amber-500 bg-amber-500 text-[#060C16] font-semibold"
                    : "border-white/10 text-slate-300 hover:border-amber-500/50 hover:text-amber-400"
              }`}
            >
              {active && <Check className="h-3.5 w-3.5" />}
              {t}
            </button>
          );
        })}
      </div>
      <p className="mt-4 text-xs text-slate-500">
        20-minute video call · Free · Confirmation by email within 24 hours
      </p>
    </div>
  );
};

export default SlotPicker;
