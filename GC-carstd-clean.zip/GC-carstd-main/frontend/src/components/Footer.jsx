import { Link } from "react-router-dom";
import { Linkedin, Instagram, Twitter, Mail, Phone, MapPin } from "lucide-react";
import { CONTACT } from "@/data/content";

export const Footer = () => (
  <footer data-testid="site-footer" className="border-t border-amber-500/15 bg-[#04080F]">
    <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-8 md:grid-cols-2 lg:grid-cols-4 lg:px-16">
      <div>
        <Link to="/" className="flex items-baseline gap-2">
          <span className="font-serif text-2xl font-semibold text-slate-50">
            GC<span className="text-amber-500">.</span>
          </span>
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-slate-400">
            Career Studio
          </span>
        </Link>
        <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-400">
          Careers, engineered. Resumes, brands, and interview craft that turn
          overlooked profiles into accepted offers.
        </p>
        <div className="mt-6 flex gap-4">
          <a href="#" aria-label="LinkedIn" data-testid="footer-social-linkedin" className="text-slate-400 transition-colors hover:text-amber-400">
            <Linkedin className="h-5 w-5" />
          </a>
          <a href="#" aria-label="Instagram" data-testid="footer-social-instagram" className="text-slate-400 transition-colors hover:text-amber-400">
            <Instagram className="h-5 w-5" />
          </a>
          <a href="#" aria-label="Twitter" data-testid="footer-social-twitter" className="text-slate-400 transition-colors hover:text-amber-400">
            <Twitter className="h-5 w-5" />
          </a>
        </div>
      </div>

      <div>
        <h4 className="font-mono text-xs uppercase tracking-[0.25em] text-amber-400">Explore</h4>
        <ul className="mt-4 space-y-3 text-sm text-slate-400">
          <li><Link to="/" className="transition-colors hover:text-amber-400">Home</Link></li>
          <li><Link to="/services" className="transition-colors hover:text-amber-400">Services</Link></li>
          <li><Link to="/about" className="transition-colors hover:text-amber-400">About</Link></li>
          <li><Link to="/testimonials" className="transition-colors hover:text-amber-400">Success Stories</Link></li>
          <li><Link to="/packages" className="transition-colors hover:text-amber-400">Packages</Link></li>
          <li><Link to="/book" className="transition-colors hover:text-amber-400">Book a Consultation</Link></li>
        </ul>
      </div>

      <div>
        <h4 className="font-mono text-xs uppercase tracking-[0.25em] text-amber-400">Services</h4>
        <ul className="mt-4 space-y-3 text-sm text-slate-400">
          <li><Link to="/services" className="transition-colors hover:text-amber-400">Resume & ATS Overhaul</Link></li>
          <li><Link to="/services" className="transition-colors hover:text-amber-400">LinkedIn & Personal Branding</Link></li>
          <li><Link to="/services" className="transition-colors hover:text-amber-400">Job-Search Strategy</Link></li>
          <li><Link to="/services" className="transition-colors hover:text-amber-400">Interview Preparation</Link></li>
          <li><Link to="/services" className="transition-colors hover:text-amber-400">1:1 Career Consultation</Link></li>
        </ul>
      </div>

      <div>
        <h4 className="font-mono text-xs uppercase tracking-[0.25em] text-amber-400">Contact</h4>
        <ul className="mt-4 space-y-3 text-sm text-slate-400">
          <li>
            <a href={`mailto:${CONTACT.email}`} data-testid="footer-email-link" className="flex items-center gap-2 transition-colors hover:text-amber-400">
              <Mail className="h-4 w-4 text-amber-500" /> {CONTACT.email}
            </a>
          </li>
          <li>
            <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} data-testid="footer-phone-link" className="flex items-center gap-2 transition-colors hover:text-amber-400">
              <Phone className="h-4 w-4 text-amber-500" /> {CONTACT.phone}
            </a>
          </li>
          <li className="flex items-start gap-2">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
            <span>{CONTACT.address}</span>
          </li>
          <li className="text-xs text-slate-500">{CONTACT.hours}</li>
        </ul>
      </div>
    </div>

    <div className="border-t border-white/5 py-6">
      <p className="mx-auto max-w-7xl px-4 text-xs text-slate-500 sm:px-8 lg:px-16">
        © {new Date().getFullYear()} GC Career Studio. All rights reserved. Crafted for the ambitious.
      </p>
    </div>
  </footer>
);

export default Footer;
