export const Marquee = ({ items }) => (
  <div
    className="overflow-hidden border-y border-amber-500/15 bg-[#0F1A2E]/40 py-4"
    data-testid="editorial-marquee"
  >
    <div className="flex w-max animate-marquee items-center gap-12 hover:[animation-play-state:paused]">
      {[...items, ...items].map((item, i) => (
        <span
          key={i}
          className="flex items-center gap-12 whitespace-nowrap font-mono text-xs uppercase tracking-[0.25em] text-slate-400"
        >
          {item}
          <span className="h-1 w-1 rounded-full bg-amber-500" aria-hidden="true" />
        </span>
      ))}
    </div>
  </div>
);

export default Marquee;
