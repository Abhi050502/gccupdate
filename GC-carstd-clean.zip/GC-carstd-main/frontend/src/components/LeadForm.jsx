import { useState } from "react";
import { CheckCircle2, Loader2, RotateCcw, CalendarCheck2 } from "lucide-react";
import { submitLead } from "@/lib/api";
import { trackEvent } from "@/lib/analytics";

const STAGES = [
  "College Student",
  "Fresher / Recent Graduate",
  "Working Professional",
  "Career Transition",
  "Executive / Leadership",
];

const GOALS = [
  "ATS-Friendly Resume",
  "LinkedIn & Personal Branding",
  "Job-Search Strategy",
  "Interview Preparation",
  "Career Direction & Consultation",
  "Not sure yet — need guidance",
];

const EMPTY = {
  name: "",
  email: "",
  phone: "",
  career_stage: "",
  goal: "",
  preferred_time: "",
  challenge: "",
};

export const LeadForm = ({ source = "website", preferredTime = "", onEditSlot }) => {
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | submitting | success | error

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const validate = () => {
    const errs = {};
    if (form.name.trim().length < 2) errs.name = "Please enter your full name";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "Enter a valid email";
    if (form.phone.replace(/\D/g, "").length < 8) errs.phone = "Enter a valid phone number";
    if (!form.career_stage) errs.career_stage = "Select your current status";
    if (!form.goal) errs.goal = "Select your primary goal";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setStatus("submitting");
    try {
      await submitLead({ ...form, preferred_time: preferredTime || form.preferred_time, source });
      trackEvent("generate_lead", { source, goal: form.goal, career_stage: form.career_stage });
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <div
        data-testid="booking-success-message"
        className="rounded-2xl border border-amber-500/30 bg-[#0F1A2E] p-8"
      >
        <CheckCircle2 className="h-10 w-10 text-amber-500" />
        <h3 className="mt-4 font-serif text-2xl text-slate-50">
          You're booked in, {form.name.split(" ")[0]}.
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-slate-400">
          A career consultant will reach out within 24 hours
          {preferredTime || form.preferred_time
            ? ` — we've noted your preference: ${preferredTime || form.preferred_time}.`
            : "."}{" "}
          A confirmation email is on its way to {form.email}.
        </p>
        <div className="mt-6 rounded-xl bg-[#060C16] p-5">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-amber-400">
            Prepare for your call
          </p>
          <ul className="mt-3 space-y-2 text-sm text-slate-300">
            <li>· Your current resume (even a rough draft)</li>
            <li>· A link to your LinkedIn profile, if you have one</li>
            <li>· One sentence about the role you want next</li>
          </ul>
        </div>
        <button
          data-testid="booking-reset-btn"
          onClick={() => {
            setForm(EMPTY);
            setStatus("idle");
          }}
          className="mt-6 flex items-center gap-2 text-sm text-slate-400 transition-colors hover:text-amber-400"
        >
          <RotateCcw className="h-4 w-4" /> Submit another request
        </button>
      </div>
    );
  }

  return (
    <form data-testid="booking-form" onSubmit={onSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="lead-name" className="field-label">Full name *</label>
          <input
            id="lead-name"
            data-testid="booking-input-name"
            className="field-input"
            placeholder="Aarav Kapoor"
            value={form.name}
            onChange={set("name")}
          />
          {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
        </div>
        <div>
          <label htmlFor="lead-email" className="field-label">Email *</label>
          <input
            id="lead-email"
            type="email"
            data-testid="booking-input-email"
            className="field-input"
            placeholder="you@example.com"
            value={form.email}
            onChange={set("email")}
          />
          {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="lead-phone" className="field-label">Phone *</label>
          <input
            id="lead-phone"
            data-testid="booking-input-phone"
            className="field-input"
            placeholder="+91 98765 43210"
            value={form.phone}
            onChange={set("phone")}
          />
          {errors.phone && <p className="mt-1 text-xs text-red-400">{errors.phone}</p>}
        </div>
        <div>
          <label htmlFor="lead-stage" className="field-label">Current status *</label>
          <select
            id="lead-stage"
            data-testid="booking-select-status"
            className="field-input"
            value={form.career_stage}
            onChange={set("career_stage")}
          >
            <option value="">Select…</option>
            {STAGES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          {errors.career_stage && <p className="mt-1 text-xs text-red-400">{errors.career_stage}</p>}
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="lead-goal" className="field-label">Primary goal *</label>
          <select
            id="lead-goal"
            data-testid="booking-select-goal"
            className="field-input"
            value={form.goal}
            onChange={set("goal")}
          >
            <option value="">Select…</option>
            {GOALS.map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
          {errors.goal && <p className="mt-1 text-xs text-red-400">{errors.goal}</p>}
        </div>
      </div>
      {preferredTime ? (
        <div className="flex items-center justify-between rounded-xl border border-amber-500/30 bg-amber-500/5 px-4 py-3">
          <span className="flex items-center gap-2 text-sm text-slate-200">
            <CalendarCheck2 className="h-4 w-4 text-amber-500" />
            <span data-testid="booking-selected-slot">{preferredTime}</span>
          </span>
          {onEditSlot && (
            <button
              type="button"
              data-testid="booking-change-slot"
              onClick={onEditSlot}
              className="text-xs font-medium text-amber-400 hover:text-amber-300"
            >
              Change
            </button>
          )}
        </div>
      ) : (
        <div>
          <label htmlFor="lead-time" className="field-label">Preferred time</label>
          <input
            id="lead-time"
            data-testid="booking-input-time"
            className="field-input"
            placeholder="e.g. Weekday evenings, Sat 11am"
            value={form.preferred_time}
            onChange={set("preferred_time")}
          />
        </div>
      )}

      <div>
        <label htmlFor="lead-challenge" className="field-label">
          Your biggest career challenge right now
        </label>
        <textarea
          id="lead-challenge"
          data-testid="booking-input-challenge"
          rows={3}
          className="field-input resize-none"
          placeholder="Tell us what's holding you back — applications ignored, unclear direction, interview nerves…"
          value={form.challenge}
          onChange={set("challenge")}
        />
      </div>

      {status === "error" && (
        <p data-testid="booking-error-message" className="text-sm text-red-400">
          Something went wrong submitting your request. Please try again.
        </p>
      )}

      <button
        type="submit"
        data-testid="booking-submit-btn"
        disabled={status === "submitting"}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-amber-500 px-6 py-3.5 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400 disabled:opacity-60"
      >
        {status === "submitting" ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" /> Sending…
          </>
        ) : (
          "Book My Free Consultation"
        )}
      </button>
      <p className="text-center text-xs text-slate-500">
        No spam, no obligation. Your details stay with GC Career Studio.
      </p>
    </form>
  );
};

export default LeadForm;
