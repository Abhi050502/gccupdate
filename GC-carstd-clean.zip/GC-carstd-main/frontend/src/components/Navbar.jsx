import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, ArrowRight } from "lucide-react";
import { trackEvent } from "@/lib/analytics";

const LINKS = [
  { to: "/", label: "Home", testId: "nav-link-home" },
  { to: "/services", label: "Services", testId: "nav-link-services" },
  { to: "/about", label: "About", testId: "nav-link-about" },
  { to: "/testimonials", label: "Success Stories", testId: "nav-link-testimonials" },
  { to: "/packages", label: "Packages", testId: "nav-link-packages" },
];

export const Navbar = () => {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  return (
    <header
      data-testid="site-header"
      className="fixed top-0 left-0 right-0 z-50 border-b border-amber-500/15 bg-[#060C16]/90 py-4 backdrop-blur-xl"
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-8 lg:px-16">
        <Link to="/" data-testid="nav-brand-logo" className="flex items-baseline gap-2">
          <span className="font-serif text-2xl font-semibold tracking-tight text-slate-50">
            GC<span className="text-amber-500">.</span>
          </span>
          <span className="hidden font-mono text-[10px] uppercase tracking-[0.3em] text-slate-400 sm:inline">
            Career Studio
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {LINKS.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              data-testid={l.testId}
              className={`text-sm transition-colors hover:text-amber-400 ${
                pathname === l.to ? "text-amber-400" : "text-slate-300"
              }`}
            >
              {l.label}
            </Link>
          ))}
          <Link
            to="/book"
            data-testid="nav-book-cta"
            onClick={() => trackEvent("cta_click", { cta: "book_consultation", location: "navbar" })}
            className="group flex items-center gap-2 rounded-full bg-amber-500 px-5 py-2.5 text-sm font-semibold text-[#060C16] transition-colors hover:bg-amber-400"
          >
            Book a Consultation
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </nav>

        <button
          data-testid="nav-mobile-toggle"
          aria-label="Toggle menu"
          onClick={() => setOpen(!open)}
          className="text-slate-200 lg:hidden"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <nav
          data-testid="nav-mobile-menu"
          className="border-t border-amber-500/10 bg-[#060C16] px-4 py-6 lg:hidden"
        >
          <div className="flex flex-col gap-4">
            {LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className={`text-base ${pathname === l.to ? "text-amber-400" : "text-slate-300"}`}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/book"
              onClick={() => setOpen(false)}
              className="mt-2 rounded-full bg-amber-500 px-5 py-3 text-center text-sm font-semibold text-[#060C16]"
            >
              Book a Consultation
            </Link>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Navbar;
