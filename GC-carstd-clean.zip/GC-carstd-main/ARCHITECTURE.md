# GC Career Studio — Architecture Write-up

## Tech stack
- **Frontend:** React 19 (CRA + craco), React Router 7, Tailwind CSS, shadcn/ui primitives, Framer Motion (kinetic hero + scroll reveals), Lenis (smooth scroll), Axios.
- **Backend:** FastAPI (async), Motor (async MongoDB driver), Pydantic v2 validation.
- **Database:** MongoDB (platform-managed). Collections mirror the future relational entities 1:1, so a later move to Postgres (or staying on Mongo) is a data-layer change only — the API contract does not change.
- **Email:** Transactional mail (owner lead notification + lead confirmation) currently sends via a Resend proxy endpoint inherited from the original build platform — see the note in `backend/email_service.py` before deploying this outside that platform.

## Folder structure
```
/app/backend
  server.py          # app factory, /api router, routes
  models.py          # Lead, Consultation, User (scaffold) — future: Service, Package, Payment...
  content_data.py    # services/packages/testimonials served by API (DB-backed later)
  email_service.py   # managed Resend proxy + safety gate (templates are server-side only)
  auth_scaffold.py   # bcrypt + JWT helpers, get_current_user dependency (not wired yet)
/app/frontend/src
  components/        # Navbar, Footer, Reveal, Marquee, LeadForm (reused by future portal)
  pages/             # Home, Services, About, Testimonials, Packages, Book
  data/content.js    # display content; pages can switch to /api endpoints with one import
  lib/api.js         # single axios client reading REACT_APP_BACKEND_URL
```

## Data model (MongoDB collections)
- `leads` — id, name, email, phone, career_stage, goal, preferred_time, challenge, source, status (`new → contacted → qualified → converted`), created_at. **This is the future CRM pipeline's stage field.**
- `consultations` — id, lead_id, scheduled_time, status (`requested → confirmed → completed`), consultant_id (null until consultants exist). A consultation row is created automatically for every lead.
- `users` — scaffolded model only (email, hashed_password, role: client/consultant/admin). No routes expose it yet.
- Reserved for later: `services`, `packages`, `documents`, `applications`, `payments`, `agreements` — all reference `users.id` / `leads.id`, which already exist.

## How future SaaS features plug in (no rebuild)
- **Client portal:** wire `auth_scaffold.py` (register/login routes issuing JWT), gate new `/api/client/*` routes with `get_current_user`, reuse `LeadForm`/form components and Tailwind tokens in a `pages/portal/` section.
- **Consultant dashboard:** `consultations.consultant_id` already exists; add `/api/consultant/queue` filtered by role claim in the JWT.
- **Admin CRM:** `leads.status` is the pipeline. Add authenticated `/api/admin/leads` list/update endpoints; the collection and status vocabulary are already in place.
- **Payments:** add a `payments` collection keyed by `lead_id`/`user_id`, call Stripe/Razorpay from a new router; the booking flow already collects everything needed to create a customer.
- **Calendar (Calendly-style):** `consultations.scheduled_time` is already stored; swap the preferred-time text input for a slot-picker writing the same field.
- **WhatsApp/CRM/analytics:** all lead capture flows through the single `POST /api/leads` handler — one place to add webhooks/integrations without touching the frontend.

## Assumptions made
- MongoDB used instead of a relational DB (platform-managed infrastructure); schema above mirrors the requested relational entities.
- No auth on the public MVP per spec; auth scaffold exists but is intentionally not exposed.
- Testimonials and metrics are realistic **placeholder** content, labeled as such, structured for real stories.
- Package prices are "Custom quote" with a Talk-to-us CTA (no checkout, per non-goals).
- Contact details in the footer are placeholders (hello@gccareerstudio.com, +91 98765 43210).
- Owner notification email requires a real `OWNER_EMAIL` in `backend/.env` (user to provide); the lead confirmation email works immediately.
