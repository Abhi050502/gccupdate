# GC Career Studio — PRD

## Original problem statement (summary)
Build a professional, conversion-focused marketing website for GC Career Studio, a career consultancy
(resumes/ATS, LinkedIn branding, job-search strategy, interview prep, career consultation) serving
students, freshers, working professionals, and career transitioners. Primary goal: lead generation and
consultation bookings. Architected to evolve into a SaaS platform (client accounts, consultant
dashboards, admin CRM, payments) without a rebuild. MVP scope: full site + working lead capture +
booking flow; packages/payments stubbed; no live auth portal.

## User personas
- College student / fresher: first resume, first interviews, needs ATS + confidence.
- Working professional: plateaued, wants better role/salary, needs strategy + positioning.
- Career transitioner: switching domains/geographies, needs reframing + roadmap.
- Business owner (admin, future): needs lead pipeline visibility (CRM).

## Core requirements (static)
1. Pages: Home, Services, About, Success Stories, Packages (placeholder tiers), Book a Consultation.
2. Problem→solution framing, repeated CTAs, social proof placeholders, how-it-works journey.
3. Lead capture form (name, email, phone, career stage, goal, preferred time, challenge) → backend DB.
4. Leads model designed for future CRM pipeline; consultations auto-created per lead.
5. Auth scaffolded (JWT/bcrypt helpers) but not exposed publicly.
6. Email: confirmation to lead + notification to owner (managed Resend proxy).
7. Awwwards-level design: ink navy + amber, Cormorant Garamond + Plus Jakarta Sans, kinetic hero,
   editorial marquee, framer-motion reveals, lenis smooth scroll, parallax hero.

## Architecture
- Frontend: React 19 + React Router 7 + Tailwind + framer-motion + lenis. Components: Navbar, Footer,
  Reveal, Marquee, LeadForm; pages per route; content in src/data/content.js (API-backed later).
- Backend: FastAPI, /api prefix. Routes: GET /api/, POST /api/leads, GET /api/services|packages|
  testimonials|metrics. Modules: models.py, content_data.py, email_service.py, auth_scaffold.py.
- DB: MongoDB — collections leads, consultations (users scaffolded in models.py).
- Docs: /app/ARCHITECTURE.md (stack, folder structure, schema, SaaS evolution path, assumptions).

## Implemented (2026-07 → verified 2026-09-06 environment date)
- All 6 pages + responsive glass navbar + full footer, all data-testids per design spec.
- Kinetic masked hero reveal, parallax hero image, editorial marquee, numbered problem chapters,
  interactive uplift estimator, journey timeline, testimonial filters, packages grid, FAQ accordion.
- POST /api/leads with validation → MongoDB lead + consultation records.
- Email integration verified live: lead confirmation email sends (202 Accepted). Owner notification
  coded but skipped until OWNER_EMAIL is provided.
- Live calendar booking (2026-09): two-step /book flow — SlotPicker (14 days, Sundays closed,
  8 IST slots/day) backed by GET /api/consultations/availability; booked slots lock automatically.
  "I'm flexible" fallback. Verified e2e: slot → details → success.
- Visitor analytics (2026-09): src/lib/analytics.js — GA4 (gtag) and Plausible support, both
  disabled unless REACT_APP_GA4_ID / REACT_APP_PLAUSIBLE_DOMAIN are set; route-change pageviews +
  cta_click (navbar/hero/packages) + generate_lead (on successful lead submit, no PII) events.
- WhatsApp confirmations: REMOVED per user request (2026-09) — keeping the flow simple; email
  confirmation is the single notification channel.
- Verified: curl on all endpoints; e2e slot booking flow; analytics confirmed off when env empty.

## Backlog
- P0: Set OWNER_EMAIL (user's real email) to activate owner lead notifications.
- P0: Provide GA4 Measurement ID (G-...) or Plausible domain to activate visitor analytics.
- P0: Provide Twilio credentials (Account SID, Auth Token, WhatsApp sender/sandbox number) to
  activate WhatsApp slot confirmations; with the sandbox, recipients must send the join code once.
- P1: Real testimonials/metrics replacing labeled placeholders.
- P2: Client portal (wire auth_scaffold), consultant dashboard, admin CRM over leads.status.
- P2: Payments (Stripe/Razorpay), WhatsApp notifications, DB-backed content editing.

## Next tasks
1. Collect owner's notification email + analytics ID → set env vars, restart, verify.
2. Seed real testimonials + metrics.
